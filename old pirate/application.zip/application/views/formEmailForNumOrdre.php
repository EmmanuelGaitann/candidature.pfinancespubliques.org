<div class="row">
    <div class="col-lg-12">
        <div class="bs-example">
            <div class="jumbotron">
                <span style="color: red">
                    La fonstionnalité de restauration de votre numéro d'ordre est en travaux, Veillez vous rapproché du de l'administration du PSSFP
                </span>
                <br/><br/>
            </div>
        </div>
    </div>
</div>
